package junit.tests.framework;

/**
 * Test class used in SuiteTest
 */
import junit.framework.TestCase;

public class NoTestCases extends TestCase {
	public void noTestCase() {
	}
}
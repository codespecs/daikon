package junit.tests.framework;

import junit.framework.*;

/**
 * A test case testing the testing framework.
 *
 */
public class Success extends TestCase {
	
	public void runTest() {
	}
	
	public void testSuccess() {
	}
}
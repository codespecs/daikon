#!/bin/sh
dfec tcas.c
g++ -g -w -o tcas.exe daikon-instrumented/tcas.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx256m daikon.Daikon -o tcas.inv daikon-output/tcas.decls daikon-output/tcas.dtrace

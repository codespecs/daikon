./replace.exe '-?' 'a&'  < inputs/temp-test/1.inp.1.1 > /dev/null
./replace.exe ' ' '@%@&'  < inputs/temp-test/777.inp.334.1 > /dev/null
./replace.exe ' ' 'NEW'  < inputs/temp-test/550.inp.238.1 > /dev/null
./replace.exe ' ' 'NEW'  < inputs/temp-test/551.inp.238.3 > /dev/null
./replace.exe ' ' 'rY NCDt+32Ilu>dr~s^1Q{0*{RLN>Muz'  < inputs/input/ruin.1224 > /dev/null
./replace.exe ' '  < inputs/input/ruin.1160 > /dev/null
./replace.exe ' *' '@%&a'  < inputs/temp-test/2298.inp.975.1 > /dev/null
./replace.exe ' *' 'a&'  < inputs/temp-test/1839.inp.782.1 > /dev/null
./replace.exe ' *' 'a&'  < inputs/temp-test/1840.inp.782.2 > /dev/null
./replace.exe ' *' 'a&'  < inputs/temp-test/1841.inp.782.3 > /dev/null
./replace.exe ' *-' '@t'  < inputs/temp-test/1828.inp.778.1 > /dev/null
./replace.exe ' *-' '@t'  < inputs/temp-test/1829.inp.778.2 > /dev/null
./replace.exe ' *-' '@t'  < inputs/temp-test/1830.inp.778.3 > /dev/null
./replace.exe ' *?' ''  < inputs/temp-test/1964.inp.834.1 > /dev/null
./replace.exe ' *?' ''  < inputs/temp-test/1965.inp.834.2 > /dev/null
./replace.exe ' *[0-9]-? [^a-c]@[*-^a-c]' ''  < inputs/temp-test/758.inp.325.1 > /dev/null
./replace.exe ' *[0-9]-? [^a-c]@[*-^a-c]' ''  < inputs/temp-test/759.inp.325.3 > /dev/null
./replace.exe ' *[0-9]@[[9-B]??[0-9]-[^-[^0-9]-[a-c][^a-c]' 'NEW'  < inputs/temp-test/1133.inp.487.1 > /dev/null
./replace.exe ' *[0-9]@[[9-B]??[0-9]-[^-[^0-9]-[a-c][^a-c]' 'NEW'  < inputs/temp-test/1134.inp.487.2 > /dev/null
./replace.exe ' *[9-B]' 'a&'  < inputs/temp-test/1274.inp.547.1 > /dev/null
./replace.exe ' *[9-B]' 'a&'  < inputs/temp-test/1275.inp.547.3 > /dev/null
./replace.exe ' *^-]-' '@n'  < inputs/temp-test/956.inp.412.1 > /dev/null
./replace.exe ' *^-]-' '@n'  < inputs/temp-test/957.inp.412.2 > /dev/null
./replace.exe ' *a-c]' '&a@%'  < inputs/temp-test/74.inp.32.1 > /dev/null
./replace.exe ' *a-c]' '&a@%'  < inputs/temp-test/75.inp.32.3 > /dev/null
./replace.exe ' -[][^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B]*$' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B]*' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B]?*'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B][][a-c][9-B]' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B][^][a-c][9-B]' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B][a-c]*$' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B][a-c]*' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B][a-c]?*' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B][a-c][9-B]'   < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -[^9-B][a-c][9-B]'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe ' -[^][^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe ' -]' 'a@nb@tc'  < inputs/temp-test/1638.inp.698.1 > /dev/null
./replace.exe ' -c*[^a-c]' 'NEW'  < inputs/temp-test/477.inp.209.1 > /dev/null
./replace.exe ' -c*[^a-c]' 'NEW'  < inputs/temp-test/478.inp.209.2 > /dev/null
./replace.exe ' -c*[^a-c]' 'NEW'  < inputs/temp-test/479.inp.209.3 > /dev/null
./replace.exe ' ?' '&'  < inputs/temp-test/54.inp.23.1 > /dev/null
./replace.exe ' [a-c]' '&'  < inputs/temp-test/634.inp.274.1 > /dev/null
./replace.exe ' [a-c]' '&'  < inputs/temp-test/635.inp.274.2 > /dev/null
./replace.exe ' [a-c]' '&'  < inputs/temp-test/636.inp.274.3 > /dev/null
./replace.exe ' [a-c]' '&@n'  < inputs/temp-test/634.inp.274.1 > /dev/null
./replace.exe ' [a-c]' '&@n'  < inputs/temp-test/635.inp.274.2 > /dev/null
./replace.exe ' [a-c]' '&@n'  < inputs/temp-test/636.inp.274.3 > /dev/null
./replace.exe ' [a-c]' '&@nfoo'  < inputs/temp-test/635.inp.274.2 > /dev/null
./replace.exe ' ^a-]' 'NEW'  < inputs/temp-test/2186.inp.925.1 > /dev/null
./replace.exe ' ^a-]' 'NEW'  < inputs/temp-test/2187.inp.925.2 > /dev/null
./replace.exe '!$' '^'  < inputs/input/ruin.1470 > /dev/null
./replace.exe '!' 'JeQwMtQsX"@?#Q1)jO;[#@Y^SE,&N$~<>FK'  < inputs/input/ruin.677 > /dev/null
./replace.exe '!' '\-'  < inputs/input/ruin.1946 > /dev/null
./replace.exe '!' 'f)n'\'':Ig"_@4},'  < inputs/input/ruin.1784 > /dev/null
./replace.exe '!2' 4  < inputs/moni/f7.inp > /dev/null
./replace.exe '"' '6'  < inputs/input/ruin.197 > /dev/null
./replace.exe '"@@' 'm'  < inputs/input/ruin.1890 > /dev/null
./replace.exe '##[0-9]?[a-b]**' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '#' '&'  < inputs/input/ruin.1044 > /dev/null
./replace.exe '#' '&G:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_JG:]y;Zm{7<\33O~h_J'  < inputs/input/ruin.1044 > /dev/null
./replace.exe '#' '_W$'  < inputs/input/ruin.1198 > /dev/null
./replace.exe '#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO#8|G=x$)8Bi3&]|}0Ei%$sGmY={x{8WXO-[^--z]-[^a--b][^0-9]@* *?-c' '@n'  < inputs/temp-test/902.inp.388.1 > /dev/null
./replace.exe '$ -[^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/528.inp.229.1 > /dev/null
./replace.exe '$ -[^9-B][a-c][9-B]' '@%&a'  < inputs/temp-test/529.inp.229.2 > /dev/null
./replace.exe '$$**' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '$%**' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '$%-[@n][^a--b]$' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '$%? ' 'a@nb@tc'  < inputs/temp-test/218.inp.97.5 > /dev/null
./replace.exe '$%?@*' 'NEW'  < inputs/temp-test/523.inp.226.5 > /dev/null
./replace.exe '$%?^$' '@%&a'  < inputs/temp-test/513.inp.223.10 > /dev/null
./replace.exe '$%@*?' '@%&a'  < inputs/temp-test/199.inp.89.5 > /dev/null
./replace.exe '$%[^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '$'   < inputs/moni/f7.inp > /dev/null
./replace.exe '$' '%'  < inputs/input/ruin.1122 > /dev/null
./replace.exe '$' ''\''Z y<j$`3-b6{hC,KW4dJZ\tWkm'  < inputs/input/ruin.1104 > /dev/null
./replace.exe '$' 'F]"8mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%`#tLmW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%mW1FGw`iK4QO;MuiQ4{%R:h2`^Ndy W4p?5Yd9N%7tp~'  < inputs/input/ruin.154 > /dev/null
./replace.exe '$' 'K'  < inputs/input/ruin.1121 > /dev/null
./replace.exe '$' 'Pb'  < inputs/input/ruin.1111 > /dev/null
./replace.exe '$' 'X'\'',id`ucU?Bhj!aeGJ~qW=F*9LTRouw#I-quWg}}wkR8Cwfff{{JGSTC2v7(*^3wSqSn{{\Jx9r8a'  < inputs/input/ruin.130 > /dev/null
./replace.exe '$' 'xv'\''%;99C.L6GYG|5'\''B4JA{:,!;i0:/n+[q}2g+Q+T[#; `w&%3:]~,5M]m.'  < inputs/input/ruin.1118 > /dev/null
./replace.exe '$- ' '&'  < inputs/temp-test/524.inp.227.1 > /dev/null
./replace.exe '$-'   < inputs/temp-test/215.inp.96.8 > /dev/null
./replace.exe '$-' '&@n'   < inputs/temp-test/215.inp.96.8 > /dev/null
./replace.exe '$-*[][^0-9]' '&'  < inputs/temp-test/201.inp.90.3 > /dev/null
./replace.exe '$-*[^0-9]$' '&'  < inputs/temp-test/202.inp.90.6 > /dev/null
./replace.exe '$-*[^0-9]' '&'  < inputs/temp-test/200.inp.90.1 > /dev/null
./replace.exe '$-*[^0-9]' '&'  < inputs/temp-test/201.inp.90.3 > /dev/null
./replace.exe '$-*[^0-9]' '&@n' < inputs/temp-test/201.inp.90.3 > /dev/null
./replace.exe '$-*[^0-9]'  < inputs/temp-test/201.inp.90.3 > /dev/null
./replace.exe '$-*[^][^0-9]' '&'  < inputs/temp-test/201.inp.90.3 > /dev/null
./replace.exe '$-[@n][^a--b]$' 'NEW'  < inputs/temp-test/215.inp.96.8 > /dev/null
./replace.exe '$-[@n][^a--b]' 'NEW'  < inputs/temp-test/213.inp.96.1 > /dev/null
./replace.exe '$-[@n][^a--b]' 'NEW'  < inputs/temp-test/214.inp.96.3 > /dev/null
./replace.exe '$-[][@n][^a--b]$' 'NEW'  < inputs/temp-test/215.inp.96.8 > /dev/null
./replace.exe '$-[^][@n][^a--b]$' 'NEW'  < inputs/temp-test/215.inp.96.8 > /dev/null
./replace.exe '$? ' 'a@nb@tc'  < inputs/temp-test/217.inp.97.1 > /dev/null
./replace.exe '$?-[^-z][0-9]' '&a@%'  < inputs/temp-test/224.inp.100.1 > /dev/null
./replace.exe '$?-[^-z][0-9]'  < inputs/temp-test/224.inp.100.1 > /dev/null
./replace.exe '$?@*'   < inputs/temp-test/522.inp.226.3 > /dev/null
./replace.exe '$?@*' '@%&a'  < inputs/temp-test/532.inp.231.1 > /dev/null
./replace.exe '$?@*' 'NEW'  < inputs/temp-test/521.inp.226.1 > /dev/null
./replace.exe '$?@*' 'NEW'  < inputs/temp-test/522.inp.226.3 > /dev/null
./replace.exe '$?[^--z]c[^9-B][^9-B]c*?[9-B]c-' '@t'  < inputs/temp-test/530.inp.230.1 > /dev/null
./replace.exe '$?[^--z]c[^9-B][^9-B]c*?[9-B]c-' '@t'  < inputs/temp-test/531.inp.230.4 > /dev/null
./replace.exe '$?^'   < inputs/temp-test/512.inp.223.3 > /dev/null
./replace.exe '$?^' '@%&a'  < inputs/temp-test/511.inp.223.1 > /dev/null
./replace.exe '$?^' '@%&a'  < inputs/temp-test/512.inp.223.3 > /dev/null
./replace.exe '$@*?' '@%&a'  < inputs/temp-test/198.inp.89.1 > /dev/null
./replace.exe '$@[*-?[a-c$' 'a@nb@tc'  < inputs/temp-test/210.inp.93.8 > /dev/null
./replace.exe '$@[*-?[a-c' 'a@nb@tc'  < inputs/temp-test/207.inp.93.1 > /dev/null
./replace.exe '$@[*-?[a-c' 'a@nb@tc'  < inputs/temp-test/208.inp.93.2 > /dev/null
./replace.exe '$@[*-?[a-c' 'a@nb@tc'  < inputs/temp-test/209.inp.93.3 > /dev/null
./replace.exe '$@[*-?[a-c'  < inputs/temp-test/207.inp.93.1 > /dev/null
./replace.exe '$[^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/525.inp.228.1 > /dev/null
./replace.exe '$[^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/526.inp.228.3 > /dev/null
./replace.exe '$[^0-9]?-?[^a--b]' '&a@%'  < inputs/temp-test/206.inp.92.1 > /dev/null
./replace.exe '$[^9-B]@['   < inputs/temp-test/219.inp.98.1 > /dev/null
./replace.exe '$[^9-B]@[' 'a@n'  < inputs/temp-test/219.inp.98.1 > /dev/null
./replace.exe '$[^9-B]@[' 'a@n'  < inputs/temp-test/220.inp.98.2 > /dev/null
./replace.exe '$[^9-B]@[' 'a@n'  < inputs/temp-test/221.inp.98.3 > /dev/null
./replace.exe '$[^9-B][9-B]'   < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^9-B][9-B]' '&@n'  < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^9-B][9-B]' '@%&a'  < inputs/temp-test/203.inp.91.1 > /dev/null
./replace.exe '$[^9-B][9-B]' '@%&a'  < inputs/temp-test/204.inp.91.2 > /dev/null
./replace.exe '$[^9-B][9-B]' '@%&a'  < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^9-B][9-B]*$'   < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^9-B][9-B][]' '@%&a'  < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^9-B][9-B][^]' '@%&a'  < inputs/temp-test/205.inp.91.3 > /dev/null
./replace.exe '$[^a-c][9-B]'   < inputs/temp-test/222.inp.99.1 > /dev/null
./replace.exe '$[^a-c][9-B]' '@%&a'  < inputs/temp-test/222.inp.99.1 > /dev/null
./replace.exe '$[^a-c][9-B]' '@%&a'  < inputs/temp-test/223.inp.99.3 > /dev/null
./replace.exe '$[^a-c]a-]' 'NEW'  < inputs/temp-test/211.inp.94.1 > /dev/null
./replace.exe '$[a-c?$' 'a&'  < inputs/temp-test/520.inp.225.8 > /dev/null
./replace.exe '$[a-c?'   < inputs/temp-test/516.inp.225.1 > /dev/null
./replace.exe '$[a-c?'   < inputs/temp-test/519.inp.225.4 > /dev/null
./replace.exe '$[a-c?' 'a&'  < inputs/temp-test/516.inp.225.1 > /dev/null
./replace.exe '$[a-c?' 'a&'  < inputs/temp-test/517.inp.225.2 > /dev/null
./replace.exe '$[a-c?' 'a&'  < inputs/temp-test/518.inp.225.3 > /dev/null
./replace.exe '$[a-c?' 'a&'  < inputs/temp-test/519.inp.225.4 > /dev/null
./replace.exe '$^-?[^9-B]' 'a@n'  < inputs/temp-test/510.inp.222.4 > /dev/null
./replace.exe '$a' ''  < inputs/moni/f7.inp > /dev/null
./replace.exe '$c*[^a-'   < inputs/temp-test/514.inp.224.1 > /dev/null
./replace.exe '$c*[^a-' 'a@nb@tc'  < inputs/temp-test/514.inp.224.1 > /dev/null
./replace.exe '$c*[^a-' 'a@nb@tc'  < inputs/temp-test/515.inp.224.3 > /dev/null
./replace.exe '$c[^0-9]' '&a@%'  < inputs/temp-test/212.inp.95.1 > /dev/null
./replace.exe '$c[^0-9]'  < inputs/temp-test/212.inp.95.1 > /dev/null
./replace.exe '% ' 'NEW'  < inputs/temp-test/552.inp.238.7 > /dev/null
./replace.exe '% *' 'a&'  < inputs/temp-test/1842.inp.782.7 > /dev/null
./replace.exe '% *^-]-$' '@n'  < inputs/temp-test/958.inp.412.11 > /dev/null
./replace.exe '%*$' ':m9#`%w*An#HIw)ZLBs!y-|, 5 M_m9u_Lao'  < inputs/input/ruin.1258 > /dev/null
./replace.exe '%*$' 'D9RnxwW@{i=z85OwG0--kJo<'  < inputs/input/ruin.1554 > /dev/null
./replace.exe '%*$' 'U'  < inputs/input/ruin.1536 > /dev/null
./replace.exe '%*$' 'i'  < inputs/input/ruin.1625 > /dev/null
./replace.exe '%*$' 'nQ;+jYa.#8vT9@X-GD(e4]YKBjzXF(V+MTO]u;aGY^jo'\''q:'  < inputs/input/ruin.1390 > /dev/null
./replace.exe '%*$' 66  < inputs/moni/f7.inp > /dev/null
./replace.exe '%*' ' <+%@x-,=f$.L5#T(AD4Q@iix)H`Ce K,+UO#:wj,q7KJO@]d~.N,<'\''Hi73GN$Gl(HX1C'  < inputs/input/ruin.328 > /dev/null
./replace.exe '%*' '0'  < inputs/input/ruin.1821 > /dev/null
./replace.exe '%*' 'G'  < inputs/input/ruin.1088 > /dev/null
./replace.exe '%*' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '%*' 'lc_lv50iK!'\''g`jS`LIK\!&3W>wi_0pbHri'  < inputs/input/ruin.1845 > /dev/null
./replace.exe '%*' 'q'  < inputs/input/ruin.1973 > /dev/null
./replace.exe '%*' 's'  < inputs/input/ruin.1058 > /dev/null
./replace.exe '%*' 's7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mp7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mp7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mp7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mp7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mpAv6)cN.l7mp'  < inputs/input/ruin.1058 > /dev/null
./replace.exe '%*' 't'  < inputs/input/ruin.526 > /dev/null
./replace.exe '%*' 'yh'  < inputs/input/ruin.1653 > /dev/null
./replace.exe '%*' '|/2:-r3lyg[Iq$dLi?"/#U'  < inputs/input/ruin.308 > /dev/null
./replace.exe '%*?$' 'vLd?Rz=SEH)PEv2'  < inputs/input/ruin.1265 > /dev/null
./replace.exe '%*?$'  < inputs/input/ruin.1265 > /dev/null
./replace.exe '%*@@$' '^^+p&y=3[ZYIgTBk:JTg x?51<dbL'  < inputs/input/ruin.1331 > /dev/null
./replace.exe '%*@@p&y=3[ZYIp&y=3[ZYIp&y=3[ZYIp&y=3[ZYIp&y=3[ZYIp&y=3[ZYIp&y=3[ZYIp&y=3[ZYIgTBk$' '^^+p&y=3[ZYIgTBk:JTg x?51<dbL'  < inputs/input/ruin.1331 > /dev/null
./replace.exe '%*B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]B]ddB]@t]*[@t@][9-B]' ' <+%@x-,=f$.L5#T(AD4Q@iix)H`Ce K,+UO#:wj,q7KJO@]d~.N,<'\''Hi73GN$Gl(HX1C'  < inputs/input/ruin.328 > /dev/null
./replace.exe '%*[O]D?'   < inputs/input/ruin.1161 > /dev/null
./replace.exe '%*[O]D?' 'dR{6FgfE'  < inputs/input/ruin.1161 > /dev/null
./replace.exe '%*\1Pf2' 'g'  < inputs/input/ruin.4 > /dev/null
./replace.exe '%*^' 'y8sdW9T'  < inputs/input/ruin.1065 > /dev/null
./replace.exe '%- ' '@t'  < inputs/temp-test/1790.inp.761.7 > /dev/null
./replace.exe '%- [^@n]?[^0-9]?[0-9]?$' '@%&a'  < inputs/temp-test/163.inp.73.10 > /dev/null
./replace.exe '%-' '%s$0#=(`Y2,;:8*/t"3Yn=VCI-|H6q[k%+sNf3%f`xvS*o(uD'  < inputs/input/ruin.1972 > /dev/null
./replace.exe '%-' ''  < inputs/temp-test/1650.inp.703.5 > /dev/null
./replace.exe '%-' 'NEW'  < inputs/temp-test/725.inp.312.5 > /dev/null
./replace.exe '%-' 'a&'  < inputs/temp-test/1312.inp.563.7 > /dev/null
./replace.exe '%-*-' '@n'  < inputs/temp-test/2009.inp.852.5 > /dev/null
./replace.exe '%-*?$' '&a@%'  < inputs/temp-test/1103.inp.474.11 > /dev/null
./replace.exe '%-*?' '&a@%'  < inputs/temp-test/1102.inp.474.5 > /dev/null
./replace.exe '%--%[^9-B][0-9]--[0-9]*-$' '@%@&'  < inputs/temp-test/18.inp.8.11 > /dev/null
./replace.exe '%--*a-c]?[^0-9]$' '@n'  < inputs/temp-test/1154.inp.496.10 > /dev/null
./replace.exe '%--@*-[^-z]-?[^--z][^9-B]?$' '&a@%'  < inputs/temp-test/503.inp.219.10 > /dev/null
./replace.exe '%--@*-[^-z]-?[^--z][^9-B]?' '&a@%'  < inputs/temp-test/501.inp.219.5 > /dev/null
./replace.exe '%--[0-9]?-?$' 'NEW'  < inputs/temp-test/2061.inp.873.10 > /dev/null
./replace.exe '%--[^9-B][0-9]--[0-9]*-$' '@%@&'  < inputs/temp-test/18.inp.8.11 > /dev/null
./replace.exe '%-?$' '&'  < inputs/temp-test/375.inp.162.10 > /dev/null
./replace.exe '%-?$' 'a&'  < inputs/temp-test/1079.inp.464.10 > /dev/null
./replace.exe '%-??[^0-9][9-B][^9-B]$' 'a&'  < inputs/temp-test/39.inp.16.11 > /dev/null
./replace.exe '%-?@[[^9-B]---?' 'a@n'  < inputs/temp-test/966.inp.416.5 > /dev/null
./replace.exe '%-?[^0-9]?' '&'  < inputs/temp-test/466.inp.203.5 > /dev/null
./replace.exe '%-@**' 'NEW'  < inputs/temp-test/1838.inp.781.5 > /dev/null
./replace.exe '%-@t$' ''  < inputs/temp-test/42.inp.17.11 > /dev/null
./replace.exe '%-[9-B]' '&'  < inputs/temp-test/1336.inp.573.5 > /dev/null
./replace.exe '%-[@n][^a--b]$'   < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[@n][^a--b]$' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[@n][^a--b]*$' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[@n][^a--b]*' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[][@n][^a--b]$' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[^0-9]' 'NEW'  < inputs/temp-test/2013.inp.854.7 > /dev/null
./replace.exe '%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]%-[^9-B]' 'NEW'  < inputs/temp-test/892.inp.383.5 > /dev/null
./replace.exe '%-[^9-B]' 'NEW'  < inputs/temp-test/892.inp.383.5 > /dev/null
./replace.exe '%-[^9-B]' 'a@nb@tc'  < inputs/temp-test/1717.inp.731.7 > /dev/null
./replace.exe '%-[^9-B][^0-9] $' 'a@n'  < inputs/temp-test/2026.inp.859.11 > /dev/null
./replace.exe '%-[^9-B][^0-9][_-z]?-^*?$' '@n'  < inputs/temp-test/1051.inp.452.11 > /dev/null
./replace.exe '%-[^][@n][^a--b]$' 'NEW'  < inputs/temp-test/216.inp.96.11 > /dev/null
./replace.exe '%-[^a-c]' '@%@&'  < inputs/temp-test/863.inp.371.5 > /dev/null
./replace.exe '%-[^a-c]' 'b@t'  < inputs/temp-test/1654.inp.704.5 > /dev/null
./replace.exe '%-]-' '@n'  < inputs/temp-test/1123.inp.483.7 > /dev/null
./replace.exe '%-][^0-9]' 'a@nb@tc'  < inputs/temp-test/580.inp.249.7 > /dev/null
./replace.exe '%-^$' ''  < inputs/temp-test/575.inp.247.10 > /dev/null
./replace.exe '%-^$' '@%&a'  < inputs/temp-test/1249.inp.535.10 > /dev/null
./replace.exe '%-^-]$' '@%&a'  < inputs/temp-test/2311.inp.980.11 > /dev/null
./replace.exe '%-^?*' ''  < inputs/temp-test/575.inp.247.10 > /dev/null
./replace.exe '%-c---[^0-9][0-9][9-B]-' '@n'  < inputs/temp-test/1034.inp.444.5 > /dev/null
./replace.exe '%-c?' '@%@&'  < inputs/temp-test/605.inp.260.5 > /dev/null
./replace.exe '%.$' 'D'  < inputs/input/ruin.1460 > /dev/null
./replace.exe '%? '   < inputs/temp-test/218.inp.97.5 > /dev/null
./replace.exe '%? ' 'a@nb@tc'  < inputs/temp-test/218.inp.97.5 > /dev/null
./replace.exe '%? *' '@t'  < inputs/temp-test/859.inp.369.5 > /dev/null
./replace.exe '%?$' '2'  < inputs/input/ruin.1261 > /dev/null
./replace.exe '%?$' '9e1'  < inputs/input/ruin.1325 > /dev/null
./replace.exe '%?$' 'AP'  < inputs/input/ruin.202 > /dev/null
./replace.exe '%?$' 'L<5GMRl"'\''7Wl'\''3=ure'\''wFll;_2}wNR7cy/'  < inputs/input/ruin.1356 > /dev/null
./replace.exe '%?$' 'TU#\gNe$1p#Jb0WI'  < inputs/input/ruin.1320 > /dev/null
./replace.exe '%?$' '\'  < inputs/input/ruin.1440 > /dev/null
./replace.exe '%?$' 'k (M~}|3y!1|/)<WQV:Mkr1'  < inputs/input/ruin.774 > /dev/null
./replace.exe '%?$' 'oN5<e4k|K|}HrFB=iZSgZHM$1+R*ygT'  < inputs/input/ruin.1872 > /dev/null
./replace.exe '%?$'  < inputs/input/ruin.1261 > /dev/null
./replace.exe '%?' ')]CS#C@X3[0J\$&a[[@mGOQ'  < inputs/input/ruin.1876 > /dev/null
./replace.exe '%?' '+'  < inputs/input/ruin.556 > /dev/null
./replace.exe '%?' '.RM'  < inputs/input/ruin.1857 > /dev/null
./replace.exe '%?' '/*XX9X]4-DijN '  < inputs/input/ruin.727 > /dev/null
./replace.exe '%?' '1'  < inputs/input/ruin.1671 > /dev/null
./replace.exe '%?' '6b/]'  < inputs/input/ruin.219 > /dev/null
./replace.exe '%?' '7 EB+%@FvoUS  '  < inputs/input/ruin.1526 > /dev/null
./replace.exe '%?' 'Q!I*e$7'  < inputs/input/ruin.1457 > /dev/null
./replace.exe '%?' 'd6|=C@vL&W124Sl,6$@BY9x[JBrfpE<o0p,J"WO\A/HIDw'  < inputs/input/ruin.585 > /dev/null
./replace.exe '%?' 'k'  < inputs/input/ruin.1361 > /dev/null
./replace.exe '%?' 'n'  < inputs/input/ruin.233 > /dev/null
./replace.exe '%?' 'qwZj/of[4fLna,@rHHd<;;1Imlc@Ya*B'  < inputs/input/ruin.1094 > /dev/null
./replace.exe '%?' 'w'  < inputs/input/ruin.1257 > /dev/null
./replace.exe '%?' '}=$="fk-Rix[&n#bBsqn8i!#\<p1+jntBsBI74.+2qg+$7!x/R'  < inputs/input/ruin.1500 > /dev/null
./replace.exe '%?*$' 'w'  < inputs/input/ruin.1257 > /dev/null
./replace.exe '%?*@*' 'NEW'  < inputs/temp-test/523.inp.226.5 > /dev/null
./replace.exe '%?-$' '@t'  < inputs/temp-test/1871.inp.793.11 > /dev/null
./replace.exe '%?-' '@n'  < inputs/temp-test/913.inp.393.5 > /dev/null
./replace.exe '%?? *' 'NEW'  < inputs/temp-test/1531.inp.655.5 > /dev/null
./replace.exe '%??-?[^@n][a-]-@*[^a--b][0-9]-$' '@%&a'  < inputs/temp-test/2249.inp.953.11 > /dev/null
./replace.exe '%??[@n]-?[9-B]-^-]??[9-B]-*[^0-9]-' '@n'  < inputs/temp-test/1347.inp.578.7 > /dev/null
./replace.exe '%??^[^9-B]@*?@**$' '@n'  < inputs/temp-test/251.inp.111.11 > /dev/null
./replace.exe '%??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**??^[^9-B]@*?@**$' '@n'  < inputs/temp-test/251.inp.111.11 > /dev/null
./replace.exe '%?@![$]@n' ''  < inputs/input/ruin.967 > /dev/null
./replace.exe '%?@*$' '@%&a'  < inputs/temp-test/534.inp.231.11 > /dev/null
./replace.exe '%?@*$' 'b@t'  < inputs/temp-test/935.inp.402.10 > /dev/null
./replace.exe '%?@*'   < inputs/temp-test/523.inp.226.5 > /dev/null
./replace.exe '%?@*' 'NEW'  < inputs/temp-test/523.inp.226.5 > /dev/null
./replace.exe '%?@@' '&a@%'  < inputs/temp-test/2230.inp.945.7 > /dev/null
./replace.exe '%?[-$' 'a&'  < inputs/temp-test/784.inp.337.11 > /dev/null
./replace.exe '%?[0-9][9-B]-$' 'a&'  < inputs/temp-test/1974.inp.838.11 > /dev/null
./replace.exe '%?[9-B][^a-c]' '@t'  < inputs/temp-test/939.inp.403.5 > /dev/null
./replace.exe '%?[9-B]^a-c]-[a-c]-[^0-9]- *?-^a-]' 'NEW'  < inputs/temp-test/1019.inp.438.5 > /dev/null
./replace.exe '%?[@@][^0-9][a-c]?-[^0-9]- [^9-B]$' 'NEW'  < inputs/temp-test/1129.inp.485.10 > /dev/null
./replace.exe '%?[]^$' '@%&a'  < inputs/temp-test/513.inp.223.10 > /dev/null
./replace.exe '%?[^9-B][^9-B]A' 'a@n'  < inputs/temp-test/1808.inp.768.5 > /dev/null
./replace.exe '%?[^@@][^--z]c-[^0-9][9-B]??' 'a@n'  < inputs/temp-test/305.inp.136.5 > /dev/null
./replace.exe '%?[^@n]^[@@][0-9]??-]' 'NEW'  < inputs/temp-test/1127.inp.484.5 > /dev/null
./replace.exe '%?[^@n]^[@@][0-9]??-]temp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.intemp-test/1183.i-*[^a-b]-*-*[^a-b]-*-*[^a-b]-*-*[^a-b]-*n' 'NEW'  < inputs/temp-test/1127.inp.484.5 > /dev/null
./replace.exe '%?[^@t]$' 'NEW'  < inputs/temp-test/1485.inp.637.10 > /dev/null
./replace.exe '%?[^]^$' '@%&a'  < inputs/temp-test/513.inp.223.10 > /dev/null
./replace.exe '%?[^a--b][0-9]A*[9-B]??[^9-B]?-' 'b@t'  < inputs/temp-test/1414.inp.606.7 > /dev/null
./replace.exe '%?[^a-c]-^?-[a-c]-?c*?[^9-B]-?' 'NEW'  < inputs/temp-test/1588.inp.676.7 > /dev/null
./replace.exe '%?[a--b]@[*[0-9][^a-c]?@*[0-9][- *[^@@][-z][9-B]- *-[a-c]$' 'NEW'  < inputs/temp-test/1743.inp.741.10 > /dev/null
./replace.exe '%?[a-]$' '@t'  < inputs/temp-test/2165.inp.915.10 > /dev/null
./replace.exe '%?[a-c$' 'a@n'  < inputs/temp-test/770.inp.330.10 > /dev/null
./replace.exe '%?[a-c-?' 'a@nb@tc'  < inputs/temp-test/2201.inp.932.5 > /dev/null
./replace.exe '%?[a-c-?' 'a@nb@tc'  < inputs/temp-test/2202.inp.932.7 > /dev/null
./replace.exe '%?^$'   < inputs/temp-test/513.inp.223.10 > /dev/null
./replace.exe '%?^$' '@%&a'  < inputs/temp-test/513.inp.223.10 > /dev/null
./replace.exe '%?^*$' 'a@n'  < inputs/temp-test/1242.inp.533.11 > /dev/null
./replace.exe '%?^*' '&a@%'  < inputs/temp-test/977.inp.420.7 > /dev/null
./replace.exe '%?c*$' '@n'  < inputs/temp-test/350.inp.153.11 > /dev/null
./replace.exe '%?c*$' '@n@'  < inputs/temp-test/350.inp.153.11 > /dev/null
./replace.exe '%@(' 'y:s*EV b!c[n@w>v'  < inputs/input/ruin.1752 > /dev/null
./replace.exe '%@*$'  < inputs/temp-test/199.inp.89.5 > /dev/null
./replace.exe '%@**-$' '&a@%'  < inputs/temp-test/137.inp.63.11 > /dev/null
./replace.exe '%@**-' '&a@%'  < inputs/temp-test/136.inp.63.5 > /dev/null
./replace.exe '%@**-' '@t'  < inputs/temp-test/1492.inp.639.5 > /dev/null
./replace.exe '%@**--[0-9]?a-c][^-$' '&'  < inputs/temp-test/280.inp.125.10 > /dev/null
./replace.exe '%@*-[^0-9]-@[[^a-c] ' 'NEW'  < inputs/temp-test/1489.inp.638.5 > /dev/null
./replace.exe '%@*?' '&@n' < inputs/temp-test/199.inp.89.5 > /dev/null
./replace.exe '%@*?' '@%&a'  < inputs/temp-test/199.inp.89.5 > /dev/null
./replace.exe '%@*?'  < inputs/temp-test/199.inp.89.5 > /dev/null
./replace.exe '%@@ ' 'L^2'\''NNI-~vNzrKq>fKK]A mg,@5N/o2s\V7N>'  < inputs/input/ruin.1640 > /dev/null
./replace.exe '%@@$' ' J5VXPw6h<vW[6**p36MrPLqh'\''Q'  < inputs/input/ruin.1167 > /dev/null
./replace.exe '%@@$' '@atD,[O7M4J)7%|eNA;t(aw'  < inputs/input/ruin.1732 > /dev/null
./replace.exe '%@@$' 'C=K8]r8DZs;rx:9A7J^=P3r4Te2f&G1'  < inputs/input/ruin.1708 > /dev/null
./replace.exe '%@@$' 'H'  < inputs/input/ruin.324 > /dev/null
./replace.exe '%@@$' 'KV5^u_vH*;0X>-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^-[^a-c][0-9]@[[0-9]*[^0-9]*-[^a-c]@n*^[^c4^sOw%oe5'\''AZr@KBq'  < inputs/input/ruin.1341 > /dev/null
./replace.exe '%@@$' 'KV5^u_vH*;0X>c4^sOw%oe5'\''AZr@KBq'  < inputs/input/ruin.1341 > /dev/null
./replace.exe '%@@$' 'zAlI%9cFthJlYpJ\@u|j6dDwUDk?N}i+ Z,hIh$"#iu4zV'  < inputs/input/ruin.515 > /dev/null
./replace.exe '%@@$?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*?[^--z]c[^9-B][^9-B]c?*' 'KV5^u_vH*;0X>c4^sOw%oe5'\''AZr@KBq'  < inputs/input/ruin.1341 > /dev/null
./replace.exe '%@@$@,5rY]~M\ Wz]`M0)y8H?fc7Phqi}@,5rY]~M\ Wz]`M0)y8H?@,5rY]~M\ Wz]`M0)y8H?fc7Phqi}@,5rY]~M\ Wz]`M0)y8H?t]*[@t@][9-B]-*[0-9]][@t]*[@t@][9-B]t]*[@t@][9-B]-*[0-9]][@t]*[@t@][9-B]' 'H'  < inputs/input/ruin.324 > /dev/null
./replace.exe '%@@' ' B!ls?r*Bk.lC'\''l<T+]?*;};+pT+]:0qdY0\L"V0w*T2'  < inputs/input/ruin.767 > /dev/null
./replace.exe '%@@' '6'  < inputs/input/ruin.190 > /dev/null
./replace.exe '%@@' '7'  < inputs/input/ruin.209 > /dev/null
./replace.exe '%@@' '<'  < inputs/input/ruin.1961 > /dev/null
./replace.exe '%@@' 'A'  < inputs/input/ruin.23 > /dev/null
./replace.exe '%@@' 'C#6L=cT|[<GnK><~'  < inputs/input/ruin.152 > /dev/null
./replace.exe '%@@' 'E'  < inputs/input/ruin.1281 > /dev/null
./replace.exe '%@@' 'H'  < inputs/input/ruin.90 > /dev/null
./replace.exe '%@@' 'Hgsuo[7/`Q'  < inputs/input/ruin.123 > /dev/null
./replace.exe '%@@' 'JOmk4tJ'  < inputs/input/ruin.223 > /dev/null
./replace.exe '%@@' 'KJ={Rl7_z1X$p:%SG'  < inputs/input/ruin.1477 > /dev/null
./replace.exe '%@@' 'M.10\?_|(0803q:sHHzal#;;M<2`.,HRVz"'\''il'  < inputs/input/ruin.133 > /dev/null
./replace.exe '%@@' 'V@'  < inputs/input/ruin.1083 > /dev/null
./replace.exe '%@@' 'Yp'  < inputs/input/ruin.3 > /dev/null
./replace.exe '%@@' 'b04ZLrhsr,4"4&K!&ZA1"ZA;]/XF3SXotQ'  < inputs/input/ruin.1226 > /dev/null
./replace.exe '%@@' 'i'  < inputs/input/ruin.472 > /dev/null
./replace.exe '%@@' 'j'  < inputs/input/ruin.38 > /dev/null
./replace.exe '%@@' 'j'  < inputs/input/ruin.441 > /dev/null
./replace.exe '%@@' 'k'  < inputs/input/ruin.1730 > /dev/null
./replace.exe '%@@' 'm|~+U+9'\''<y9E'  < inputs/input/ruin.1120 > /dev/null
./replace.exe '%@@' 'sI1TM{>'\''bMi-}&'  < inputs/input/ruin.477 > /dev/null
./replace.exe '%@@' 'tU/3F0P2)T;xy=$:fIU'  < inputs/input/ruin.781 > /dev/null
./replace.exe '%@@' 'w'  < inputs/input/ruin.1634 > /dev/null
./replace.exe '%@@' '}Y}'  < inputs/input/ruin.1314 > /dev/null
./replace.exe '%@@*$' 'm|~+U+9'\''<y9E'  < inputs/input/ruin.1120 > /dev/null
./replace.exe '%@@*' 'p'  < inputs/input/ruin.283 > /dev/null
./replace.exe '%@@*[^9-B] *-c*[-' '&a@%'  < inputs/temp-test/1497.inp.641.7 > /dev/null
./replace.exe '%@@=' ')&hL~6sDzLioa!)wc9QfBOO'\''qiXG^o1*za&dr |;Z%Nn^h*rq'  < inputs/input/ruin.399 > /dev/null
./replace.exe '%@@?$' '>A('  < inputs/input/ruin.751 > /dev/null
./replace.exe '%@@@@@@$' 'PxkC zwUtqc`<IFt"RoQ!F'\''D9z7OL;xo$/o&6XdE=StMNWl|iTbck%*z'  < inputs/input/ruin.525 > /dev/null
./replace.exe '%@@@@\x[^v]@@' '/!OJ=t,WAMc%C'  < inputs/input/ruin.344 > /dev/null
./replace.exe '%@@\' '_e/7aN*GF0pWy#='  < inputs/input/ruin.310 > /dev/null
./replace.exe '%@[*[9-B]' '&'  < inputs/temp-test/492.inp.215.5 > /dev/null
./replace.exe '%@[*[9-B]@' '&'  < inputs/temp-test/492.inp.215.5 > /dev/null
./replace.exe '%@[*[a-c]$' 'NEW'  < inputs/temp-test/1372.inp.588.11 > /dev/null
./replace.exe '%@[[^9-B][_-z]c^a-]^*-?[^0-9]-[^9-B]' 'a&'  < inputs/temp-test/2269.inp.961.5 > /dev/null
./replace.exe '%@d' 'fg~4[LmRA3o6:cW<[RU@3H*M;Z:.;y'\'',gC?= VPAFmAF'\'':1)z3<<'  < inputs/input/ruin.377 > /dev/null
./replace.exe '%@n' '`'  < inputs/input/ruin.1158 > /dev/null
./replace.exe '%@n' 'l|'  < inputs/input/ruin.1775 > /dev/null
./replace.exe '%@n' 'v'  < inputs/input/ruin.1561 > /dev/null
./replace.exe '%@n'  < inputs/input/ruin.1158 > /dev/null
./replace.exe '%@n?' ''  < inputs/input/ruin.1860 > /dev/null
./replace.exe '%@t$' '\_'  < inputs/input/ruin.1586 > /dev/null
./replace.exe '%@t*' '@'  < inputs/input/ruin.1787 > /dev/null
./replace.exe '%A' ':45s3M%Yaoud%{~QFrbA`:&NwJ9(nw}Qy=?D['  < inputs/input/ruin.1115 > /dev/null
./replace.exe '%A*$' ':45s3M%Yaoud%{~QFrbA`:&NwJ9(nw}Qy=?D['  < inputs/input/ruin.1115 > /dev/null
./replace.exe '%A*[^0-9]*$' '@%@&'  < inputs/temp-test/36.inp.15.10 > /dev/null
./replace.exe '%A[0-9]?@**[a-c][^0-9]$' '@%&a'  < inputs/temp-test/672.inp.292.11 > /dev/null
./replace.exe '%E$' 'I'  < inputs/input/ruin.1790 > /dev/null
./replace.exe '%E' 'E'  < inputs/input/ruin.1184 > /dev/null
./replace.exe '%E?' 'h'  < inputs/input/ruin.903 > /dev/null
./replace.exe '%O$' '\'  < inputs/input/ruin.683 > /dev/null
./replace.exe '%P$' 'dLQ('  < inputs/input/ruin.1532 > /dev/null
./replace.exe '%S' ' P'  < inputs/input/ruin.1601 > /dev/null
./replace.exe '%S?*' ' P'  < inputs/input/ruin.1601 > /dev/null
./replace.exe '%U' 'N+2rHDje[,A_^!$*}]k`e2{1lp*{^'  < inputs/input/ruin.15 > /dev/null
./replace.exe '%U' 'h<z?cC=|(I]>/deslsGqiEdmY'  < inputs/input/ruin.1760 > /dev/null
./replace.exe '%V' '`wtFDA"\YWV{x=qMe@$iJ&LgdV'  < inputs/input/ruin.757 > /dev/null
./replace.exe '%V' 'd'  < inputs/input/ruin.1707 > /dev/null
./replace.exe '%WQtcc@n' '( $V0B&16|L'  < inputs/input/ruin.270 > /dev/null
./replace.exe '%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@[[%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@[%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@[%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@[' '@n'  < inputs/temp-test/2096.inp.888.5 > /dev/null
./replace.exe '%[-z][^9-B]?--[^9-B]-[^9-B][^9-B]-?@[' '@n'  < inputs/temp-test/2096.inp.888.5 > /dev/null
./replace.exe '%[0-4-1]' '-1'  < inputs/moni/f7.inp > /dev/null
./replace.exe '%[0-9H]$' 'l*>nm)BOulbBc1&N6A'  < inputs/input/ruin.549 > /dev/null
./replace.exe '%[0-9]' 'l'  < inputs/input/ruin.1572 > /dev/null
./replace.exe '%[0-9]**' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '%[0-9]-[9-B]?-[9-B]^-]?$' 'NEW'  < inputs/temp-test/1672.inp.712.10 > /dev/null
./replace.exe '%[0-9]?' '@t'  < inputs/temp-test/1048.inp.451.5 > /dev/null
./replace.exe '%[0-9]@@' '@%&a'  < inputs/temp-test/1696.inp.723.5 > /dev/null
./replace.exe '%[0-9]@[*' '@n'  < inputs/temp-test/844.inp.362.5 > /dev/null
./replace.exe '%[0-9][^9-B][@t][^a-c]' '@%&a'  < inputs/temp-test/1040.inp.447.5 > /dev/null
./replace.exe '%[1]*@@' '@YLmg{>yPr b&3<TkY4-a|k+L63(J^$~xY:n\b6%fo3[-n, =}@e'  < inputs/input/ruin.626 > /dev/null
./replace.exe '%[9-B]' '&'  < inputs/temp-test/2307.inp.979.7 > /dev/null
./replace.exe '%[9-B]-$' 'NEW'  < inputs/temp-test/1455.inp.623.10 > /dev/null
./replace.exe '%[9-B]?$' '&a@%'  < inputs/temp-test/2045.inp.867.10 > /dev/null
./replace.exe '%[9-B]?' '@%&a'  < inputs/temp-test/801.inp.344.5 > /dev/null
./replace.exe '%[9-B]?-@[*[^9-B]-@tc*a-]' '@n'  < inputs/temp-test/1536.inp.657.7 > /dev/null
./replace.exe '%[9-B][^a--]' 'a@nb@tc'  < inputs/temp-test/1355.inp.581.5 > /dev/null
./replace.exe '%[9-B]c*?@[*-? $' '&'  < inputs/temp-test/436.inp.191.10 > /dev/null
./replace.exe '%[>-AA-G>-A]' '%'  < inputs/input/ruin.801 > /dev/null
./replace.exe '%[>-A]$' 'Rob"FQFK`\,mU`gzl<R<1`Ns4W.g'  < inputs/input/ruin.371 > /dev/null
./replace.exe '%[@t]- [^0-9][^a-^?@n?$' 'a&'  < inputs/temp-test/2252.inp.954.10 > /dev/null
./replace.exe '%[@t]@*?[^-[9-B]-' 'b@t'  < inputs/temp-test/1732.inp.736.5 > /dev/null
./replace.exe '%[A-G0-9]' 'aKzJRRKf,'\''We6;r+n+]pU-`P}I'  < inputs/input/ruin.988 > /dev/null
./replace.exe '%[A-G]' 'P'  < inputs/input/ruin.730 > /dev/null
./replace.exe '%[A-G]' 'xeD;,?BG|~6y8P D&x*"3r^Ej5VL$'  < inputs/input/ruin.1081 > /dev/null
./replace.exe '%[I]'   < inputs/input/ruin.1156 > /dev/null
./replace.exe '%[I]' 'r?alRkSvq6'  < inputs/input/ruin.1156 > /dev/null
./replace.exe '%[R]$' 'f&<'  < inputs/input/ruin.9 > /dev/null
./replace.exe '%[Z-a]^_`a]$' 'easgtgK\'\''\*W LdSez|/"f'  < inputs/input/ruin.76 > /dev/null
./replace.exe '%[]? ' 'a@nb@tc'  < inputs/temp-test/218.inp.97.5 > /dev/null
./replace.exe '%[][^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^-z] ' 'NEW'  < inputs/temp-test/248.inp.110.5 > /dev/null
./replace.exe '%[^0-9] [^9-B]--[0-9]??[a-c]?-' ''  < inputs/temp-test/568.inp.244.5 > /dev/null
./replace.exe '%[^0-9]' '&'  < inputs/temp-test/665.inp.289.5 > /dev/null
./replace.exe '%[^0-9]' '@%@&'  < inputs/temp-test/2005.inp.851.5 > /dev/null
./replace.exe '%[^0-9]*$' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^0-9]*' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^0-9]-' '@%&a'  < inputs/temp-test/1570.inp.670.5 > /dev/null
./replace.exe '%[^0-9]-?[9-B]?-[9-B]?'   < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^0-9]?' '@%@&'  < inputs/temp-test/942.inp.404.5 > /dev/null
./replace.exe '%[^0-9]?*' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^0-9]@t*' '&a@%'  < inputs/temp-test/461.inp.202.5 > /dev/null
./replace.exe '%[^0-9]A?' '@n'  < inputs/temp-test/1835.inp.780.7 > /dev/null
./replace.exe '%[^0-9][^0-9][^9-B]' '@n'  < inputs/temp-test/1955.inp.829.5 > /dev/null
./replace.exe '%[^0-9][a--][^9-B][^-z]$' 'a@nb@tc'  < inputs/temp-test/2256.inp.956.10 > /dev/null
./replace.exe '%[^0-9][a-]$' ''  < inputs/temp-test/151.inp.68.10 > /dev/null
./replace.exe '%[^0-9][a-c]$' ''  < inputs/temp-test/728.inp.313.10 > /dev/null
./replace.exe '%[^9-B]$' 'a&'  < inputs/temp-test/1539.inp.658.10 > /dev/null
./replace.exe '%[^9-B]-' '@%&a'  < inputs/temp-test/2131.inp.902.5 > /dev/null
./replace.exe '%[^9-B]?' '&'  < inputs/temp-test/2161.inp.914.5 > /dev/null
./replace.exe '%[^9-B]?' '@%@&'  < inputs/temp-test/1555.inp.665.5 > /dev/null
./replace.exe '%[^9-B]?-[^9-B]-*-[^9-B][^0-9]-*-[^0-9]$' '@%&a'  < inputs/temp-test/1083.inp.466.10 > /dev/null
./replace.exe '%[^9-B]?[a-c-?a-][^a-]-?-[9-B][0-9][^a-c*[0-9][^0-9]@[[9-B][^a-c]$' ''  < inputs/temp-test/1224.inp.525.10 > /dev/null
./replace.exe '%[^9-B][9-B]-*?[^@@]-a-]-' '@%&a'  < inputs/temp-test/2143.inp.907.5 > /dev/null
./replace.exe '%[^9-B][a-c]$' '@%&a'  < inputs/temp-test/1306.inp.561.10 > /dev/null
./replace.exe '%[^>-A]' 'm})h'  < inputs/input/ruin.816 > /dev/null
./replace.exe '%[^>-A]' 'rw`h-v1P5_?OU7NRz`:a9HNb]H="9cjwym["lqG<!&sYJc^dbfdN7N2ms3E ZS&g'  < inputs/input/ruin.666 > /dev/null
./replace.exe '%[^>-A]' 'w'  < inputs/input/ruin.1698 > /dev/null
./replace.exe '%[^?z-}>-A0-9A-GZ-a]^_`a-c-ac-a]' 'NA'  < inputs/input/ruin.293 > /dev/null
./replace.exe '%[^?z-}>-A0-9A-GZ-a]^_`a-c-ac-a]@n' 'N&A'  < inputs/input/ruin.293 > /dev/null
./replace.exe '%[^A-G]$' 'Pb'  < inputs/input/ruin.1111 > /dev/null
./replace.exe '%[^A-G]' '(Qk '  < inputs/input/ruin.1205 > /dev/null
./replace.exe '%[^B]' 'o'  < inputs/input/ruin.733 > /dev/null
./replace.exe '%[^Z-a]^_`a]' 'J=iYas^_]iYPHxV5eUw(z'  < inputs/input/ruin.1660 > /dev/null
./replace.exe '%[^]? ' 'a@nb@tc'  < inputs/temp-test/218.inp.97.5 > /dev/null
./replace.exe '%[^][^0-9]-?[9-B]?-[9-B]?' '@t'  < inputs/temp-test/527.inp.228.5 > /dev/null
./replace.exe '%[^a-' '&'  < inputs/temp-test/2316.inp.982.7 > /dev/null
./replace.exe '%[^a-?[a-]?-?-]' '&'  < inputs/temp-test/49.inp.20.7 > /dev/null
./replace.exe '%[^a-c]' '@%@&'  < inputs/temp-test/2282.inp.966.7 > /dev/null
./replace.exe '%[^a-c]???@*?[^a-c][a-c[^9-B]$' 'NEW'  < inputs/temp-test/484.inp.211.10 > /dev/null
./replace.exe '%[^a-c]?[^0-9]a-c][9-B]c*?[^0-9]$' ''  < inputs/temp-test/1295.inp.555.10 > /dev/null
./replace.exe '%[^a-c]?[^0-9]a-c][9-B]c*?[^0-9]' ''  < inputs/temp-test/1294.inp.555.7 > /dev/null
./replace.exe '%[^a-c]@t*$' '@t'  < inputs/temp-test/1191.inp.512.10 > /dev/null
./replace.exe '%[^a-c]@t*' '@t'  < inputs/temp-test/1190.inp.512.7 > /dev/null
./replace.exe '%[^a-c][0-9]' 'a&'  < inputs/temp-test/1784.inp.759.5 > /dev/null
./replace.exe '%[^a-c][9-B]$' '@%@&'  < inputs/temp-test/1644.inp.700.10 > /dev/null
./replace.exe '%[^a-c]^*' '@%@&'  < inputs/temp-test/2300.inp.976.5 > /dev/null
./replace.exe '%[^c-a>-A]' 'q\)&urQRC6v%ZLu%T%'  < inputs/input/ruin.1358 > /dev/null
./replace.exe '%[^~>-A<]' 'W'  < inputs/input/ruin.1816 > /dev/null
./replace.exe '%[_-z]-' '@n'  < inputs/temp-test/811.inp.348.7 > /dev/null
./replace.exe '%[a-?$' 'NEW'  < inputs/temp-test/737.inp.316.11 > /dev/null
./replace.exe '%[a-]-*[a-c][^a--]-$' '@t'  < inputs/temp-test/1091.inp.470.10 > /dev/null
./replace.exe '%[a-b]?**' 'a'  < inputs/moni/f7.inp > /dev/null
./replace.exe '%[a-c-@@[0-9][^a-]?a-c]--c*$' '@%@&'  < inputs/temp-test/1976.inp.839.10 > /dev/null
./replace.exe '%[a-c[^9-B]' '@%@&'  < inputs/temp-test/1431.inp.614.7 > /dev/null
./replace.exe '%[a-c]$' 'a@nb@tc'  < inputs/temp-test/1342.inp.576.11 > /dev/null
./replace.exe '%[a-c]-$' 'a@nb@tc'  < inputs/temp-test/1632.inp.694.10 > /dev/null
./replace.exe '%[a-c]?[^9-B][9-B][^a--b][0-9]-@@*' '@%&a'  < inputs/temp-test/490.inp.214.7 > /dev/null
./replace.exe '%[a-c]?[^9-B][9-B][^a--b][0-9]-@@*@' '@%&a'  < inputs/temp-test/490.inp.214.7 > /dev/null
./replace.exe '%[a-c][^0-9]*[a-c]' '&@n'  < inputs/temp-test/693.inp.300.5 > /dev/null
./replace.exe '%[a-c][^0-9]*[a-c]' '&@nmohaw'  < inputs/temp-test/693.inp.300.5 > /dev/null
./replace.exe '%[a-c][^0-9]-*-[a-c]-' '@n'  < inputs/temp-test/693.inp.300.5 > /dev/null
./replace.exe '%[c-az-}z-}>-AA-Gz-}z-}c-a]r' '%'  < inputs/input/ruin.1529 > /dev/null
./replace.exe '%[g]' 'JR]VaH^{mV&/1Ta}4.dF0WCLpBLR8AShG"$St'  < inputs/input/ruin.1432 > /dev/null
./replace.exe '%[k]' 'T'  < inputs/input/ruin.475 > /dev/null
./replace.exe '%[q0-9]' '.^u>`Y~4'\''!d;?[6eMR*)X+D>xU%AUWv8y$.jdQ@jBn='\''(J8f,KIL4L'  < inputs/input/ruin.285 > /dev/null
./replace.exe '%[z-}Z-a]^_`a->-A>-A-c-ac-a-A-GABCDEFGl-A-GABCDEFG~-A-GABCDEFG-z-}z-}!-A-GABCDEFG]' '=h'  < inputs/input/ruin.770 > /dev/null
./replace.exe '%[z-}]$' 'h'  < inputs/input/ruin.898 > /dev/null
./replace.exe '%^' 'x'  < inputs/input/ruin.1600 > /dev/null
./replace.exe '%^*??-$' '@%@&'  < inputs/temp-test/2242.inp.950.10 > /dev/null
./replace.exe '%^*[^@@]-?^a-][a--][^@@]?-[0-9]' '@%@&'  < inputs/temp-test/1684.inp.717.5 > /dev/null
./replace.exe '%^*[^a--]$' 'a&'  < inputs/temp-test/257.inp.113.10 > /dev/null
./replace.exe '%^*a-c]' '@%&a'  < inputs/temp-test/2247.inp.952.7 > /dev/null
./replace.exe '%^-$' '&'  < inputs/temp-test/875.inp.375.11 > /dev/null
./replace.exe '%^-]?' '&'  < inputs/temp-test/1768.inp.752.5 > /dev/null
./replace.exe '%^-]@**' 'b@t'  < inputs/temp-test/743.inp.318.5 > /dev/null
./replace.exe '%^?*' 'x'  < inputs/input/ruin.1600 > /dev/null
./replace.exe '%^a-]?a-][^a-]' ''  < inputs/temp-test/449.inp.196.7 > /dev/null
./replace.exe '%^a-][9-B][^--z]??@[*?$' 'a&'  < inputs/temp-test/2154.inp.911.10 > /dev/null
./replace.exe '%^a-c]-' 'NEW'  < inputs/temp-test/194.inp.87.7 > /dev/null
./replace.exe '%^a-c]?*' 'NEW'  < inputs/temp-test/194.inp.87.7 > /dev/null
./replace.exe '%^a-c][a-c]$' 'b@t'  < inputs/temp-test/1059.inp.455.10 > /dev/null
./replace.exe '%a' kkkkkkkkkkkkk  < inputs/moni/f7.inp > /dev/null
./replace.exe '%a' kkkkkkkkkkkkk$  < inputs/moni/f7.inp > /dev/null
./replace.exe '%a-]-*?c[^--z]a-][^a-][a--b]?' 'a&'  < inputs/temp-test/1327.inp.569.5 > /dev/null
./replace.exe '%a-]@@*$' 'NEW'  < inputs/temp-test/1204.inp.516.10 > /dev/null
./replace.exe '%a-c]-[0-9]@t*@*?$' '@%@&'  < inputs/temp-test/993.inp.427.10 > /dev/null
./replace.exe '%a-c][^@@]' '@t'  < inputs/temp-test/1515.inp.648.7 > /dev/null
./replace.exe '%a[ ]*' '&@t'  < inputs/moni/f8.inp > /dev/null
./replace.exe '%a[ ]*[ ]c$' '&@n'  < inputs/moni/f8.inp > /dev/null
./replace.exe '%c' '&a@%'  < inputs/temp-test/312.inp.139.7 > /dev/null
./replace.exe '%c*' '&a@%'  < inputs/temp-test/2088.inp.884.5 > /dev/null
./replace.exe '%dB' 'P'  < inputs/input/ruin.517 > /dev/null
./replace.exe '%e@n[^>-A/]$' '98&)4@z=|'\''-xLsL|#?_(vf/fhZ'  < inputs/input/ruin.201 > /dev/null
./replace.exe '%f' '\'  < inputs/input/ruin.1034 > /dev/null
./replace.exe '%f' '\KNy,h0_sbVxG=nOfj@KNy,h0_sbVxG=nOfj@KNy,h0_sbVxG=nOfj@KNy,h0_sbVxG=nOfj@'  < inputs/input/ruin.1034 > /dev/null
./replace.exe '[^a-c]?$' 'a@n'  < inputs/temp-test/70.inp.30.9 > /dev/null
./replace.exe '[^a-c]?' '&a@%'  < inputs/temp-test/2031.inp.862.1 > /dev/null

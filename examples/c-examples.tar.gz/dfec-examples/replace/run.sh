#!/bin/sh
dfec replace.c
g++ -g -w -o replace.exe daikon-instrumented/replace.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx256m daikon.Daikon -o replace.inv daikon-output/replace.decls daikon-output/replace.dtrace

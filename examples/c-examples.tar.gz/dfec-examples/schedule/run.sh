#!/bin/sh
dfec schedule.c
g++ -g -w -o schedule.exe daikon-instrumented/schedule.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx768m daikon.Daikon -o schedule.inv daikon-output/schedule.decls daikon-output/schedule.dtrace

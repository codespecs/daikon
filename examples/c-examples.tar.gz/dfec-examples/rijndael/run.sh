#!/bin/sh
wget 'http://www.esat.kuleuven.ac.be/~rijmen/rijndael/rijndaelref.zip'
unzip rijndaelref.zip
cd ref22
patch <../rijndael.patch
dfec rijndael-alg-ref.c rijndael-api-ref.c rijndaeltest-ref.c rijndael-alg-ref.h rijndael-api-ref.h
g++ -g -w -o rijndaeltest-ref.exe daikon-instrumented/rijndael-alg-ref.cc daikon-instrumented/rijndael-api-ref.cc daikon-instrumented/rijndaeltest-ref.cc  $DFECDIR/daikon_runtime.o
./rijndaeltest-ref.exe
java -Xmx256m daikon.Daikon -o rijndaeltest-ref.inv daikon-output/rijndael-alg-ref.decls daikon-output/rijndael-api-ref.decls daikon-output/rijndaeltest-ref.decls daikon-output/rijndael-alg-ref.dtrace

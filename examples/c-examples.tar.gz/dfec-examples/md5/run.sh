#!/bin/sh
dfec md5.c md5.h main.c
g++ -g -w -o md5.exe daikon-instrumented/md5.cc daikon-instrumented/main.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx256m daikon.Daikon -o md5.inv daikon-output/md5.decls daikon-output/main.decls daikon-output/md5.dtrace

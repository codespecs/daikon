./md5.exe -d"" > /dev/null
./md5.exe -d"a" > /dev/null
./md5.exe -d"abc" > /dev/null
./md5.exe -d"message digest" > /dev/null
./md5.exe -d"abcdefghijklmnopqrstuvwxyz" > /dev/null
./md5.exe -d"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789" > /dev/null
./md5.exe -d"12345678901234567890123456789012345678901234567890123456789012345678901234567890" > /dev/null

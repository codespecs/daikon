#!/bin/sh
dfec print_tokens.c stream.h tokens.h
g++ -g -w -o print_tokens.exe \
    daikon-instrumented/print_tokens.cc \
    $DFECDIR/daikon_runtime.o
export DTRACEAPPEND=1
sh tests.sh
java -Xmx256m daikon.Daikon -o print_tokens.inv \
     daikon-output/print_tokens.decls \
     daikon-output/print_tokens.dtrace

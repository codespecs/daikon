
/* stream.h code */


#include <stdio.h>
#define SUCCEED 1
#define FAIL 0

typedef
       FILE *character_stream;
typedef
       int BOOLEAN;
typedef
       char CHARACTER;
typedef
       char *STRING;

extern char get_char(character_stream fp);
extern char unget_char(char ch, character_stream fp);
extern int is_end_of_character_stream();
extern character_stream open_character_stream(char *fname);

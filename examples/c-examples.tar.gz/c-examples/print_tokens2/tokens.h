/* tokens.h code */

#include <stdio.h> 
#include "stream.h"
#define error 0
#define keyword 1
#define spec_symbol 2
#define identifier 3
#define num_constant 41
#define str_constant 42
#define char_constant 43
#define comment 5
#define end 6

typedef
    FILE *token_stream;
typedef   
    char *token;

extern token_stream open_token_stream(char *fname);
extern token get_token(token_stream tp);
extern void print_token(token tok);
extern int is_eof_token(token tok);
extern int compare_token();

static int token_type(token);
static int is_comment(token);
static int is_keyword(token);
static int is_char_constant(token);
static int is_num_constant(token);
static int is_str_constant(token);
static int is_identifier(token);
static int is_spec_symbol(token);
static void unget_error(token_stream);
static void print_spec_symbol(token);


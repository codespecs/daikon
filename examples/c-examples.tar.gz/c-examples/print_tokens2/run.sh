#!/bin/sh
dfec print_tokens2.c stream.h tokens.h
g++ -g -w -o print_tokens2.exe \
    daikon-instrumented/print_tokens2.cc \
    $DFECDIR/daikon_runtime.o
export DTRACEAPPEND=1
sh tests.sh
java -Xmx256m daikon.Daikon -o print_tokens2.inv \
     daikon-output/print_tokens2.decls \
     daikon-output/print_tokens2.dtrace

#!/bin/sh
dfec schedule2.c schedule2.h
g++ -g -w -o schedule2.exe daikon-instrumented/schedule2.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx256m daikon.Daikon -o schedule2.inv daikon-output/schedule2.decls daikon-output/schedule2.dtrace

#!/bin/sh
dfec tot_info.c chisq.h gamma.h std.h
g++ -g -w -o tot_info.exe daikon-instrumented/tot_info.cc $DFECDIR/daikon_runtime.o
DTRACEAPPEND=1 sh tests.sh
java -Xmx256m daikon.Daikon -o tot_info.inv daikon-output/tot_info.decls daikon-output/tot_info.dtrace
